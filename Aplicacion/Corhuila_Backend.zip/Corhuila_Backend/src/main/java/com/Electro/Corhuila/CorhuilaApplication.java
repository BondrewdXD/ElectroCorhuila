package com.Electro.Corhuila;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorhuilaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorhuilaApplication.class, args);
	}

}
