package com.Electro.Corhuila.application.service;

import org.springframework.stereotype.Service;

import com.Electro.Corhuila.domain.models.Tarifa;
import com.Electro.Corhuila.domain.models.Usuario;
import com.Electro.Corhuila.domain.repository.TarifaRepository;
import com.Electro.Corhuila.domain.repository.UsuarioRepository;

@Service
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;
    private final TarifaRepository tarifaRepository;

    public UsuarioService(UsuarioRepository usuarioRepository, TarifaRepository tarifaRepository){
        this.usuarioRepository = usuarioRepository;
        this.tarifaRepository = tarifaRepository;
    }

    public Usuario crearUsuario(String nombre, String direccion, int estrato) {
        Tarifa tarifa = tarifaRepository.buscarPorEstrato(estrato)
                            .orElseThrow(() -> new RuntimeException("Tarifa no encontrada"));
        Usuario usuario = new Usuario(null,nombre, direccion, estrato, tarifa);
        return usuarioRepository.guardar(usuario);
    }
}
