package com.Electro.Corhuila.domain.models;

public class Tarifa {
    private Long id;
    private int estrato;
    private double valor;
    public Tarifa(Long id, int estrato, double valor) {
        this.id = id;
        this.estrato = estrato;
        this.valor = valor;
    }
    public Long getId() {
        return id;
    }
    public int getEstrato() {
        return estrato;
    }
    public double getValor() {
        return valor;
    }
    
}
