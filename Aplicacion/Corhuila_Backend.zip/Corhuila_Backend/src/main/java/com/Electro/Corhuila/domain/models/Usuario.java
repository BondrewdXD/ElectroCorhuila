package com.Electro.Corhuila.domain.models;

public class Usuario {
    private Long id;
    private String nombre;
    private String direccion;
    private int estrato;
    private Tarifa tarifa;
    public Usuario(Long id, String nombre, String direccion, int estrato, Tarifa tarifa) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.estrato = estrato;
        this.tarifa = tarifa;
    }
    public Long getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public int getEstrato() {
        return estrato;
    }
    public Tarifa getTarifa() {
        return tarifa;
    }
    
}
