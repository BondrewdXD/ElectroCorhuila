package com.Electro.Corhuila.domain.repository;

import java.util.List;
import java.util.Optional;

import com.Electro.Corhuila.domain.models.Tarifa;

public interface TarifaRepository{
    Optional<Tarifa> buscarPorEstrato(int estrato);
    List<Tarifa> Listar();
}
