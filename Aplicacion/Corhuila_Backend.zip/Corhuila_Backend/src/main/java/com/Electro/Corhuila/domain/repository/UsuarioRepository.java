package com.Electro.Corhuila.domain.repository;

import java.util.List;
import java.util.Optional;

import com.Electro.Corhuila.domain.models.Usuario;

public interface UsuarioRepository{
    Usuario guardar(Usuario usuario);
    Optional<Usuario> buscarPorId (Long id);
    List<Usuario> listar();
}
