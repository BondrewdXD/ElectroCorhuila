package com.Electro.Corhuila.infrastructure.persistence.JPA;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Electro.Corhuila.infrastructure.persistence.entity.TarifaEntity;

public interface TarifaJpaRepository extends JpaRepository<TarifaEntity, Long> {

}
