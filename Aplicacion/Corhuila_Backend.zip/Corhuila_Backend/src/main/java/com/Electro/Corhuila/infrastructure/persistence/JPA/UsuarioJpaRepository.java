package com.Electro.Corhuila.infrastructure.persistence.JPA;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Electro.Corhuila.infrastructure.persistence.entity.UsuarioEntity;

public interface UsuarioJpaRepository extends JpaRepository<UsuarioEntity, Long> {

}
