package com.Electro.Corhuila.infrastructure.persistence.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.Electro.Corhuila.domain.models.Tarifa;
import com.Electro.Corhuila.domain.repository.TarifaRepository;
import com.Electro.Corhuila.infrastructure.persistence.JPA.TarifaJpaRepository;
import com.Electro.Corhuila.infrastructure.persistence.mapper.TarifaMapper;

@Repository
public class TarifaRepositoryImpl implements TarifaRepository{

    private final TarifaJpaRepository JpaRepository;
    private final TarifaMapper mapper;

    public TarifaRepositoryImpl(TarifaJpaRepository jpaRepository, TarifaMapper mapper) {
        this.JpaRepository = jpaRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<Tarifa> buscarPorEstrato(int estrato) {
        return JpaRepository.findAll()
                .stream()
                .filter(t -> t.getEstrato() == estrato)
                .findFirst()
                .map(mapper::toDomain);
    }

    @Override
    public List<Tarifa> Listar() {
        return JpaRepository.findAll().stream().map(mapper::toDomain).collect(Collectors.toList());
    }
}
