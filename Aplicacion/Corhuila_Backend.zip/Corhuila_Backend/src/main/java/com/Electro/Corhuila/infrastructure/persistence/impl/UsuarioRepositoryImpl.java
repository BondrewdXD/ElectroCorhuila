package com.Electro.Corhuila.infrastructure.persistence.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.Electro.Corhuila.domain.models.Usuario;
import com.Electro.Corhuila.domain.repository.UsuarioRepository;
import com.Electro.Corhuila.infrastructure.persistence.JPA.UsuarioJpaRepository;
import com.Electro.Corhuila.infrastructure.persistence.entity.UsuarioEntity;
import com.Electro.Corhuila.infrastructure.persistence.mapper.UsuarioMapper;

@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository{
    
    private final UsuarioJpaRepository JpaRepository;
    private final UsuarioMapper mapper;

    public UsuarioRepositoryImpl(UsuarioJpaRepository jpaRepository, UsuarioMapper mapper) {
        this.JpaRepository = jpaRepository;
        this.mapper = mapper;
    }

    @Override
    public Usuario guardar(Usuario usuario) {
        UsuarioEntity saved = JpaRepository.save(mapper.toEntity(usuario));
        return mapper.toDomain(saved);
    }

    @Override
    public Optional<Usuario> buscarPorId(Long id) {
        return JpaRepository.findById(id).map(mapper::toDomain);
    }

    @Override
    public List<Usuario> listar() {
        return JpaRepository.findAll().stream().map(mapper::toDomain).collect(Collectors.toList());
    }
}
