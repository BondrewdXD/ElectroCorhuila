package com.Electro.Corhuila.infrastructure.persistence.mapper;

import org.springframework.stereotype.Component;

import com.Electro.Corhuila.domain.models.Tarifa;
import com.Electro.Corhuila.infrastructure.persistence.entity.TarifaEntity;



@Component
public class TarifaMapper {
    public Tarifa toDomain(TarifaEntity entity) {
        return new Tarifa(entity.getId(), entity.getEstrato(), entity.getValor());
    }

    public TarifaEntity toEntity(Tarifa tarifa) {
        TarifaEntity entity = new TarifaEntity();
        entity.setId(tarifa.getId());
        entity.setEstrato(tarifa.getEstrato());
        entity.setValor(tarifa.getValor());
        return entity;
    }
}
