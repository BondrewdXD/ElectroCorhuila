package com.Electro.Corhuila.infrastructure.persistence.mapper;

import org.springframework.stereotype.Component;

import com.Electro.Corhuila.domain.models.Usuario;
import com.Electro.Corhuila.infrastructure.persistence.entity.UsuarioEntity;

@Component
public class UsuarioMapper {
    
    private final TarifaMapper tarifaMapper;

    public UsuarioMapper(TarifaMapper tarifaMapper) {
        this.tarifaMapper = tarifaMapper;
    }

    public Usuario toDomain(UsuarioEntity entity) {
        return new Usuario(
            entity.getId(),
            entity.getNombre(),
            entity.getDireccion(),
            entity.getEstrato(),
            tarifaMapper.toDomain(entity.getTarifa())
        );
    }

    public UsuarioEntity toEntity(Usuario usuario) {
        UsuarioEntity entity = new UsuarioEntity();
        entity.setId(usuario.getId());
        entity.setNombre(usuario.getNombre());
        entity.setDireccion(usuario.getDireccion());
        entity.setEstrato(usuario.getEstrato());
        entity.setTarifa(tarifaMapper.toEntity(usuario.getTarifa()));
        return entity;
    }
}
