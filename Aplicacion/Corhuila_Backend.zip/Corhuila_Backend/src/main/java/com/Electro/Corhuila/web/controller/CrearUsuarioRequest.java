package com.Electro.Corhuila.web.controller;

import com.Electro.Corhuila.domain.models.Tarifa;

public class CrearUsuarioRequest {
    private String nombre;
    private String direccion;
    private int estrato;
    private Tarifa tarifa;
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public int getEstrato() {
        return estrato;
    }
    public void setEstrato(int estrato) {
        this.estrato = estrato;
    }
    public Tarifa getTarifa() {
        return tarifa;
    }
    public void setTarifa(Tarifa tarifa) {
        this.tarifa = tarifa;
    }

    
}
