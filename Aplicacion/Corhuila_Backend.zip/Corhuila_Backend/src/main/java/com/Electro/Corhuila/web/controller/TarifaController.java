package com.Electro.Corhuila.web.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Electro.Corhuila.domain.repository.TarifaRepository;

@CrossOrigin(origins = "http://localhost:8100")
@RestController
@RequestMapping("/tarifas")
public class TarifaController {

    private final TarifaRepository tarifaRepository;

    public TarifaController(TarifaRepository tarifaRepository) {
        this.tarifaRepository = tarifaRepository;
    }

    @GetMapping("/{estrato}")
    public ResponseEntity<TarifaDTO> obtenerTarifaPorEstrato(@PathVariable int estrato) {
        return tarifaRepository.buscarPorEstrato(estrato)
            .map(tarifa -> ResponseEntity.ok(new TarifaDTO(tarifa.getEstrato(), tarifa.getValor())))
            .orElse(ResponseEntity.notFound().build());
    }
}
