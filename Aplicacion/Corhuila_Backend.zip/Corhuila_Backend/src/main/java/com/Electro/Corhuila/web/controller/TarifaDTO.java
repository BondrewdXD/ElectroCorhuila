package com.Electro.Corhuila.web.controller;

public class TarifaDTO {
    private int estrato;
    private double valor;

    public TarifaDTO(int estrato, double valor) {
        this.estrato = estrato;
        this.valor = valor;
    }

    public int getEstrato() {
        return estrato;
    }

    public double getValor() {
        return valor;
    }
}
