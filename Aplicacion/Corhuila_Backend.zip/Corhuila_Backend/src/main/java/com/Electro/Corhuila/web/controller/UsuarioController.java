package com.Electro.Corhuila.web.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Electro.Corhuila.application.service.UsuarioService;
import com.Electro.Corhuila.domain.models.Usuario;

@CrossOrigin(origins = "http://localhost:8100")
@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService){
        this.usuarioService=usuarioService;
    }

    @PostMapping
    public ResponseEntity<UsuarioDTO> crearUsuario(@RequestBody CrearUsuarioRequest request){
        Usuario usuario = usuarioService.crearUsuario(request.getNombre(), request.getDireccion(), request.getEstrato());
        return ResponseEntity.ok(new UsuarioDTO(usuario));
    }
}
