package com.Electro.Corhuila.web.controller;

import com.Electro.Corhuila.domain.models.Usuario;

public class UsuarioDTO {
    private Long id;
    private String nombre;
    private String direccion;
    private int estrato;
    private double valorTarifa;

    public UsuarioDTO(Usuario usuario) {
        this.id = usuario.getId();
        this.nombre = usuario.getNombre();
        this.direccion = usuario.getDireccion();
        this.estrato = usuario.getEstrato();
        this.valorTarifa = usuario.getTarifa().getValor();
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public int getEstrato() {
        return estrato;
    }

    public double getValorTarifa() {
        return valorTarifa;
    }

    
}
