INSERT INTO tarifas (estrato, valor) VALUES (1, 20000), (2, 30000), (3, 40000), (4, 50000);
