import FormularioUsuario from "../component/FormularioUsuario";

export default function RegistroUsuario() {
  return (
    <div>
      <h2>Registro de Usuario</h2>
      <FormularioUsuario />
    </div>
  );
}
