import { useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';

interface LocationState {
  nombre: string;
  estrato: number;
}

const UserStratum: React.FC = () => {
  const location = useLocation<LocationState>();
  const { nombre, estrato } = location.state || { nombre: '', estrato: 0 };

  const [tarifa, setTarifa] = useState<number | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTarifa = async () => {
      try {
        const response = await fetch(`http://localhost:8080/tarifas/${estrato}`);
        if (response.ok) {
          const data = await response.json();
          setTarifa(data.valor);
        } else {
          setError('Error al obtener la tarifa');
        }
      } catch (err) {
        setError('Error de conexión al servidor');
      }
    };

    fetchTarifa();
  }, [estrato]);

  return (
    <div style={{ padding: '20px', color: 'white' }}>
      <h1>¡Bienvenido, {nombre}!</h1>
      <p>Tu estrato asignado es: <strong>{estrato}</strong></p>
      {tarifa !== null ? (
        <p>La tarifa correspondiente es: <strong>${tarifa}</strong></p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <p>Cargando tarifa...</p>
      )}
    </div>
  );
};

export default UserStratum;